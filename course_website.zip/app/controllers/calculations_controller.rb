class CalculationsController < ApplicationController
end
